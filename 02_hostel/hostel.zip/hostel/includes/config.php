<?php
$dbuser="uy28blic_b";
$dbpass="uy28blic_b";
$host="localhost";
$db="uy28blic_b";
$mysqli =new mysqli($host,$dbuser, $dbpass, $db);
?>